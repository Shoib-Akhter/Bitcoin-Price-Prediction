# 11785_bitcoin_price_prediction
11785 Project for using sentiment and historical price for predicting the bitcoin price. 
